using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace laba12.Views.Calculator
{
    public class ResultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
